﻿function mult(a,b) {
	return a + b;
}
function sqr(n) {
	return mult(n, n);
}
function log(n) {
	let data = sqr(n);
	console.log(data);
}
log(5);

/////

function foo() {
	console.log("Hi!");
}
function bar() {
	foo();
}
function baz() {
	bar();
}
baz();

/////
function foo() {
	return foo();
}
foo();

/////
let btn = document.querySelector("button");
button.addEventListener("click", function() {
	console.log("Clicked!");
})
setTimeout(function onTimeout() {
	console.log("Timeout Done");
}, 5000);
console.log("Done there");

/////
setTimeout(function onTimeout() {
	console.log("Hi");
}, 1000);
setTimeout(function onTimeout() {
	console.log("Hi");
}, 1000);
setTimeout(function onTimeout() {
	console.log("Hi");
}, 1000);
setTimeout(function onTimeout() {
	console.log("Hi");
}, 1000);




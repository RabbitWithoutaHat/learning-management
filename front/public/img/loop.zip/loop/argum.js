function getSomething(a, b) {
  // console.log(arguments);
  if (arguments.length === 2) {
    console.log(`${a} or ${b}`);
  } else {
    let str = `${a} or ${b}`
    for (let i = 2; i < arguments.length; i++) {
      str += ` ${arguments[i]}`;
    }
    console.log(str);
  }
}

getSomething("to be", "not to be");
getSomething("to be");
// to be or not to be
getSomething("to be", "not to be", undefined, "That is the question!");
// // to be or not to be - ошибки не будет!
console.log(process.argv);

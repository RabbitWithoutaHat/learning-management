function doThis(str) {
  console.log(`I did ${str}`);
}
doThis("jump");

// setTimeout(doThis, 2000, "sleep");


// let intID = setInterval(doThis, 1500, "eat");
// let intID2 = setInterval(doThis, 1500, "drink");
// console.log(intID);
// console.log(intID2);
//
// // setTimeout(clearInterval, 3000, intID);
// clearInterval(intID);

let fs = require("fs");

fs.appendFile("file.txt", "Hello JavaScript!\n", () => {
  fs.appendFile("file.txt", "Hello Everyone!\n", () => {
    fs.appendFile("file.txt", "Hello World!\n", () => {
      fs.readFile("file.txt", "utf-8", (err, data) => {
        console.log(data);
      })
    });
  });
});



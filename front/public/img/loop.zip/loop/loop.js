console.log("Hello!");

setTimeout(() => {
  console.log("Everyone");
}, 0);

console.log("Good Bye");
